import { Component } from '@angular/core';

@Component({
  selector: 'app-homedetail-cards',
  templateUrl: './homedetail-cards.component.html',
  styleUrls: ['./homedetail-cards.component.css']
})
export class HomedetailCardsComponent {

}
