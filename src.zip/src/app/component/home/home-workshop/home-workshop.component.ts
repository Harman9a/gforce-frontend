import { Component } from '@angular/core';

@Component({
  selector: 'app-home-workshop',
  templateUrl: './home-workshop.component.html',
  styleUrls: ['./home-workshop.component.css']
})
export class HomeWorkshopComponent {

}
