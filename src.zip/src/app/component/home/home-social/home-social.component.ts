import { Component } from '@angular/core';

@Component({
  selector: 'app-home-social',
  templateUrl: './home-social.component.html',
  styleUrls: ['./home-social.component.css'],
})
export class HomeSocialComponent {}
