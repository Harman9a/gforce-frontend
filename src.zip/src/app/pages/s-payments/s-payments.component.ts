import { Component } from '@angular/core';

@Component({
  selector: 'app-s-payments',
  templateUrl: './s-payments.component.html',
  styleUrls: ['./s-payments.component.css']
})
export class SPaymentsComponent {

}
