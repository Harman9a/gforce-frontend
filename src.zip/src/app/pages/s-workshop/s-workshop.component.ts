import { Component } from '@angular/core';

@Component({
  selector: 'app-s-workshop',
  templateUrl: './s-workshop.component.html',
  styleUrls: ['./s-workshop.component.css']
})
export class SWorkshopComponent {

}
