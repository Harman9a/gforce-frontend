import { Component } from '@angular/core';

@Component({
  selector: 'app-s-claesses',
  templateUrl: './s-claesses.component.html',
  styleUrls: ['./s-claesses.component.css'],
})
export class SClaessesComponent {}
