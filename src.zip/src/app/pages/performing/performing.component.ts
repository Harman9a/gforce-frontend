import { Component } from '@angular/core';

@Component({
  selector: 'app-performing',
  templateUrl: './performing.component.html',
  styleUrls: ['./performing.component.css']
})
export class PerformingComponent {

}
