import { Component } from '@angular/core';

@Component({
  selector: 'app-workshop-view',
  templateUrl: './workshop-view.component.html',
  styleUrls: ['./workshop-view.component.css']
})
export class WorkshopViewComponent {

}
