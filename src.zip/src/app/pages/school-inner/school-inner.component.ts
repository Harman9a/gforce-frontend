import { Component } from '@angular/core';

@Component({
  selector: 'app-school-inner',
  templateUrl: './school-inner.component.html',
  styleUrls: ['./school-inner.component.css']
})
export class SchoolInnerComponent {

}
